n2epack v0.05 (c) 2004 Crystal Chips

LICENSES
========

  This version uses the ucl library, which is under GPL license, available at
http://www.oberhumer.com/opensource/ucl/ You can find a copy of the GPL license
at the following location: http://www.gnu.org/copyleft/gpl.html

  We provide the ucl sources in order to statically link the compressor inside
n2epack's binary, however no changes were made to these sources.


COMPILING
=========

  We provide various ways to compile n2epack, depending on your operating system
and compilation needs. Here are some basic guidelines about the targets we
provide, but feel free to ask us any question about them.


  + Linux (or any compatible unix)
        requires gcc, binutils, and make.
    $ cd n2epack/src/linux
    $ make
Notes: It should work on any compatible platform, but we couldn't test anything
-----  else than linux platforms.


  + Windows, using cygwin
        requires gcc, binutils, and make.
    $ cd n2epack/src/cygwin
    $ make
Notes: This source code doesn't require any specific cygwin code to run. The
-----  cygwin target is only here per request.


  + Windows, using mingw32
        requires mingw-gcc, binutils, and make.
    $ cd n2epack/src/mingw
    $ make
Notes: Mingw32 is available under cygwin. You only have to install the mingw
-----  runtime package through your normal cygwin's setup.exe.


  + Windows, cross compiling using mingw32 from a debian host
        requires mingw32-gcc, mingw32-binutils}, and make.
    $ cd n2epack/src/mingw
    $ make -f Makefile.debian
Notes: The debian distribution offers mingw32 packages to cross compile mingw32
-----  targets. Other distributions might offer such package.


  + Windows, using Visual C++ 6
        requires Visual C++ 6
    Open the n2epack\src\vs6\n2epack.dsw file, and hit f7.


  + Windows, using Visual Studio .net 2003
        requires Visual Studio .net 2003
    Open the n2epack\src\vs2k3\n2epack.sln file, and hit f7.


  + Windows, using Visual C++ Toolkit 2003
        requires Visual C++ Toolkit 2003
    Start the Visual C++ Toolkit 2003 command prompt
    > cd n2epack\src\vctoolkit
    > makeit
Notes: the Visual C++ Toolkit 2003 is a free package offered by Microsoft. You
-----  can download it here: http://msdn.microsoft.com/visualc/vctoolkit2003/
