// N2EPack (c) 2006-2023 asmblur
//
// compress a file using N2E compression.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <ucl/ucl.h>

typedef unsigned char   u8;
typedef unsigned short  u16;
typedef unsigned int    u32;

int filesize(int fd)
{
    int size;

    size = lseek(fd, 0, SEEK_END);
    lseek(fd, 0, SEEK_SET);

    return(size);
}

int LoadFileBuffer(char *fname, u8 **buf)
{
    int fd;
    int fsize;

#if defined (__CYGWIN__) || defined (__MINGW32__)
    if((fd = open(fname, O_RDONLY | O_BINARY)) < 0)
#else
    if((fd = open(fname, O_RDONLY)) < 0)
#endif
    {
        return(-1);
    }

    if((fsize = filesize(fd)) <= 0)
    {
        close(fd);
        return(-2);
    }

    if((*buf = (u8 *) (malloc(fsize + 1))) == NULL)
    {
        close(fd);
        return(-3);
    }

    if(read(fd, *buf, fsize) < fsize)
    {
        close(fd);
        free(*buf);
        return(-4);
    }

    close(fd);
    ((u8 *) (*buf))[fsize] = '\0';

    return(fsize);
}

int SaveFileBuffer(char *fname, u8 *buf, int fsize)
{
    int fd;

#if defined (__CYGWIN__) || defined (__MINGW32__)
    if((fd = open(fname, O_WRONLY | O_CREAT | O_TRUNC | O_BINARY)) < 0)
    if((fd = open(fname, O_WRONLY | O_BINARY)) < 0)
#else
    if((fd = open(fname, O_WRONLY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE)) < 0)
    if((fd = open(fname, O_WRONLY)) < 0)
#endif
    {
        return(-1);
    }

    if(write(fd, buf, fsize) < fsize)
    {
        close(fd);
        return(-2);
    }

    close(fd);
    return(0);
}


void printUsage(void)
{
    printf("usage:\n");
    printf("\n2epack input_file output_file\n");
}

int main(int argc, char *argv[])
{
    u8 *in_buf, *out_buf;
    int in_len, out_len;

    if(argc < 3) { printUsage(); return(-1); }

    if((in_len = LoadFileBuffer(argv[1], &in_buf)) <= 0)
    {
        printf("Error loading input file '%s'!\n", argv[1]);
        return(-2);
    }

    if((out_buf = (u8 *) malloc(in_len)) == NULL)
    {
        free(in_buf);
        printf("Failed allocating %d bytes of memory for output buffer!\n", in_len);
        return(-3);
    }

    out_len = in_len;

    if(ucl_nrv2e_99_compress(in_buf, in_len, out_buf, &out_len, NULL, 10, NULL, NULL) != UCL_E_OK)
    {
        free(in_buf);
        free(out_buf);
        printf("Failed compressing input file, this file may not be compressable!\n");
        return(-4);
    }

    free(in_buf);

    if(SaveFileBuffer(argv[2], out_buf, out_len) != 0)
    {
        free(out_buf);
        printf("Failed saving output file '%s'!\n", argv[2]);
        return(-5);
    }

    free(out_buf);

    return(0);
}
